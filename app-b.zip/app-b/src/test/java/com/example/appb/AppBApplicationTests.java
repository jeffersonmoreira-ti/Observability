package com.example.appb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppBApplicationTests {

	@Test
	void contextLoads() {
	}

}
