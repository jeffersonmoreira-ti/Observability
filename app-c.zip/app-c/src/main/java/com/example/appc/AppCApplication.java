package com.example.appc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCApplication.class, args);
	}

}
